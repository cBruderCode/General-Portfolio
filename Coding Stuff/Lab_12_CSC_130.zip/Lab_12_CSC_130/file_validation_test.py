#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Check to see if Block-2048 board files are valid.

author: J. Hollingsworth and D. Hutchings
last updated: Nov 09 2020
"""

# Task 2
# Given: function header including list, quantities as inputs
# - return message if the number of rows is incorrect
# - return message if any number of columns is incorrect
# - return message if any item in list is not number and not .
# - return message of valid otherwise 
def is_board_valid(board_lines, num_rows, num_cols):

    pass # delete the line when you start this task


# Task 1
# - Given: function header including file name as input
# - Open the file and read the lines into a list
# - Remove the first list item
#   - return message if the first item is not x y format
# - Convert each of x and y to an int
#   - return message if x or y is not an int
# - Call is_board_valid with list and each int and then 
#   return whatever that call returns
def is_file_valid(board_file_name):

    pass # delete the line when you start this task


# Task 3
# - Given: function header including input, which is a
#          dictionary (file name->message)
# - Open a specific output file for writing
# - Write each name/message pair to the file on a new line
def save_to_file(results):

    pass # delete the line when you start this task


# Main program
if __name__ == '__main__':
    files = {
        'valid': 4,
        'invalid': 17
    }
    results = {}    
    for file_head, qty in files.items():
        for n in range(1, qty + 1):
            file_name = f'f{file_head}-{n}.txt'
            results[file_name] = is_file_valid(file_name)
    for file_name, message in results.items():
        print(file_name, message)
    save_to_file(results)
    